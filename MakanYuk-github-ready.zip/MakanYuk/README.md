# MakanYuk (Tahap 4B (semua fitur))

Buka folder ini di Android Studio (Koala 2024.1.1 atau lebih baru, JDK 17 bawaan), tunggu Gradle sync, lalu Run.
Build APK debug: Build > Build Bundle(s) / APK(s) > Build APK(s).
