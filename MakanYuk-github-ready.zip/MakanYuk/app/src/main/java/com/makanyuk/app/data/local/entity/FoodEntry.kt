package com.makanyuk.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** scheduleId: jadwal yang ditandai selesai oleh catatan ini (dipakai untuk progress harian). */
@Entity(tableName = "food_entry", indices = [Index("timeMillis")])
data class FoodEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val timeMillis: Long,
    val category: String,
    val note: String = "",
    val eaten: Boolean = true,
    val scheduleId: Long? = null
)
