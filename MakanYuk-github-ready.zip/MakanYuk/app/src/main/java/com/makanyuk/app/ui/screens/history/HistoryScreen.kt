package com.makanyuk.app.ui.screens.history

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.makanyuk.app.AppContainer
import com.makanyuk.app.data.local.entity.FoodEntry
import com.makanyuk.app.domain.DayCount
import com.makanyuk.app.domain.StatsCalculator
import com.makanyuk.app.domain.model.MealCategory
import com.makanyuk.app.ui.components.*
import com.makanyuk.app.ui.util.*
import java.time.LocalDate

@Composable
fun HistoryScreen(container: AppContainer, onEditEntry: (Long) -> Unit) {
    val vm: EntriesViewModel = viewModel(factory = SimpleFactory { EntriesViewModel(container) })
    val entries by vm.entries.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf(0) }
    var toDelete by remember { mutableStateOf<FoodEntry?>(null) }

    toDelete?.let { e ->
        ConfirmDialog(
            title = "Hapus catatan?",
            text = "\"${e.name}\" akan dihapus dari riwayat.",
            confirmLabel = "Hapus",
            onConfirm = { vm.delete(e); toDelete = null },
            onDismiss = { toDelete = null }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Text(
            "Riwayat",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 8.dp)
        )
        ScrollableTabRow(
            selectedTabIndex = tab,
            edgePadding = 16.dp,
            containerColor = MaterialTheme.colorScheme.background
        ) {
            listOf("Harian", "Mingguan", "Statistik", "Makanan").forEachIndexed { i, title ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) })
            }
        }
        when (tab) {
            0 -> DailyTab(entries, onEditEntry, onDelete = { toDelete = it })
            1 -> WeeklyTab(entries)
            2 -> StatsTab(entries)
            else -> FoodsTab(entries)
        }
    }
}

// ---------------- Harian ----------------
@Composable
private fun DailyTab(entries: List<FoodEntry>, onEdit: (Long) -> Unit, onDelete: (FoodEntry) -> Unit) {
    var epochDay by rememberSaveable { mutableStateOf(LocalDate.now().toEpochDay()) }
    var showPicker by remember { mutableStateOf(false) }
    val date = LocalDate.ofEpochDay(epochDay)
    val dayEntries = remember(entries, epochDay) {
        entries.filter { StatsCalculator.dateOf(it) == date }.sortedBy { it.timeMillis }
    }
    val eatenCount = dayEntries.count { it.eaten }

    if (showPicker) {
        AppDatePickerDialog(
            initial = date,
            onConfirm = { epochDay = it.toEpochDay(); showPicker = false },
            onDismiss = { showPicker = false }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { epochDay -= 1 }) {
                Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, contentDescription = "Hari sebelumnya")
            }
            TextButton(onClick = { showPicker = true }, modifier = Modifier.weight(1f)) {
                Text(formatDateLong(date), style = MaterialTheme.typography.titleMedium)
            }
            IconButton(onClick = { epochDay += 1 }) {
                Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = "Hari berikutnya")
            }
        }
        Text(
            if (dayEntries.isEmpty()) "Belum ada catatan" else "$eatenCount makanan dimakan",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        if (dayEntries.isNotEmpty()) {
            LazyColumn(contentPadding = PaddingValues(16.dp)) {
                item {
                    AppCard {
                        dayEntries.forEach { e ->
                            FoodEntryRow(e, onClick = { onEdit(e.id) }, onDelete = { onDelete(e) })
                        }
                    }
                }
            }
        }
    }
}

// ---------------- Mingguan ----------------
@Composable
private fun WeeklyTab(entries: List<FoodEntry>) {
    var weekEpoch by rememberSaveable { mutableStateOf(StatsCalculator.weekStart(LocalDate.now()).toEpochDay()) }
    val start = LocalDate.ofEpochDay(weekEpoch)
    val counts = remember(entries, weekEpoch) { StatsCalculator.weekCounts(entries, start) }
    val total = counts.sumOf { it.count }
    val activeDays = counts.count { it.count > 0 }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { weekEpoch -= 7 }) {
                Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, contentDescription = "Minggu sebelumnya")
            }
            Text(
                formatWeekRange(start),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            IconButton(onClick = { weekEpoch += 7 }) {
                Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = "Minggu berikutnya")
            }
        }
        WeekChart(counts)
        AppCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Total: $total makanan", style = MaterialTheme.typography.titleMedium)
                Text("Hari yang ada catatan: $activeDays dari 7", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun WeekChart(counts: List<DayCount>) {
    val max = (counts.maxOfOrNull { it.count } ?: 0).coerceAtLeast(1)
    val today = LocalDate.now()
    AppCard {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            counts.forEach { dc ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${dc.count}", style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(4.dp))
                    Box(
                        Modifier
                            .width(24.dp)
                            .height((8 + 90f * dc.count / max).dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                when {
                                    dc.count == 0 -> MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                    dc.date == today -> MaterialTheme.colorScheme.tertiary
                                    else -> MaterialTheme.colorScheme.primary
                                }
                            )
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(DayLabels[dc.date.dayOfWeek.value - 1], style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

// ---------------- Statistik ----------------
@Composable
private fun StatsTab(entries: List<FoodEntry>) {
    val stats = remember(entries) { StatsCalculator.compute(entries, LocalDate.now()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("${stats.days} hari terakhir", style = MaterialTheme.typography.titleMedium)
        if (stats.totalEaten == 0) {
            AppCard {
                Text(
                    "Belum ada data. Mulai catat makananmu hari ini!",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            return@Column
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Berturut-turut", "${stats.streak} hari", Modifier.weight(1f))
            StatCard("Hari tercatat", "${stats.activeDays}/${stats.days}", Modifier.weight(1f))
            StatCard("Rata-rata", String.format(IndonesianLocale, "%.1f/hari", stats.averagePerActiveDay), Modifier.weight(1f))
        }

        SectionTitle("Kebiasaan per kategori")
        AppCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                MealCategory.entries.forEach { c ->
                    val n = stats.categoryCounts[c] ?: 0
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${categoryEmoji(c.name)} ${c.label}", style = MaterialTheme.typography.bodyMedium)
                            Text("$n", style = MaterialTheme.typography.bodyMedium)
                        }
                        LinearProgressIndicator(
                            progress = { if (stats.totalEaten == 0) 0f else n.toFloat() / stats.totalEaten },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
                            trackColor = MaterialTheme.colorScheme.background
                        )
                    }
                }
            }
        }

        SectionTitle("Makanan paling sering")
        AppCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                stats.topFoods.forEachIndexed { i, (name, count) ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${i + 1}. $name", style = MaterialTheme.typography.bodyLarge)
                        Text("${count}×", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    AppCard(modifier = modifier) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelMedium)
        }
    }
}

// ---------------- Makanan yang pernah dicatat ----------------
@Composable
private fun FoodsTab(entries: List<FoodEntry>) {
    val foods = remember(entries) { StatsCalculator.distinctFoods(entries) }
    if (foods.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text("Belum ada makanan yang dicatat.", style = MaterialTheme.typography.bodyLarge)
        }
        return
    }
    LazyColumn(contentPadding = PaddingValues(16.dp)) {
        item {
            AppCard {
                foods.forEach { f ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(f.name, style = MaterialTheme.typography.titleMedium)
                            Text("Terakhir: ${formatDateShort(f.lastEaten)}", style = MaterialTheme.typography.bodyMedium)
                        }
                        Text("${f.count}×", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}
