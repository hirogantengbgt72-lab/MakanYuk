package com.makanyuk.app.domain.model

enum class MealCategory(val label: String) {
    SARAPAN("Sarapan"),
    MAKAN_SIANG("Makan siang"),
    MAKAN_MALAM("Makan malam"),
    CAMILAN("Camilan");

    companion object {
        /** Tebakan kategori awal berdasarkan jam; pengguna tetap bisa mengubahnya. */
        fun defaultFor(hour: Int): MealCategory = when {
            hour < 10 -> SARAPAN
            hour < 15 -> MAKAN_SIANG
            hour < 17 -> CAMILAN
            hour < 21 -> MAKAN_MALAM
            else -> CAMILAN
        }

        fun fromName(name: String): MealCategory = entries.firstOrNull { it.name == name } ?: CAMILAN
    }
}
