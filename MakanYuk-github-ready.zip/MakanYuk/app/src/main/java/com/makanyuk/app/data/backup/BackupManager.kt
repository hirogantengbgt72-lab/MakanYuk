package com.makanyuk.app.data.backup

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.makanyuk.app.data.local.AppDatabase
import com.makanyuk.app.data.local.entity.FoodEntry
import com.makanyuk.app.data.local.entity.FoodItem
import com.makanyuk.app.data.local.entity.MealSchedule
import com.makanyuk.app.data.prefs.UserPrefsRepository
import com.makanyuk.app.domain.model.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Backup/restore ke file JSON lewat Storage Access Framework (tanpa izin storage). */
class BackupManager(
    private val context: Context,
    private val db: AppDatabase,
    private val prefs: UserPrefsRepository
) {
    companion object { private const val FORMAT_VERSION = 1 }

    suspend fun export(uri: Uri) = withContext(Dispatchers.IO) {
        val p = prefs.current()
        val json = JSONObject().apply {
            put("app", "MakanYuk")
            put("version", FORMAT_VERSION)
            put("exportedAt", System.currentTimeMillis())
            put("prefs", JSONObject().apply {
                put("userName", p.userName)
                put("themeMode", p.themeMode.name)
                put("schoolDays", JSONArray(p.schoolDays.sorted()))
                put("notificationsEnabled", p.notificationsEnabled)
                put("soundUri", p.soundUri ?: JSONObject.NULL)
            })
            put("schedules", JSONArray().apply {
                db.mealScheduleDao().getAll().forEach { s ->
                    put(JSONObject().apply {
                        put("id", s.id); put("name", s.name); put("hour", s.hour); put("minute", s.minute)
                        put("category", s.category); put("message", s.message); put("enabled", s.enabled)
                        put("daysMask", s.daysMask); put("skipOnSchoolDays", s.skipOnSchoolDays)
                    })
                }
            })
            put("foodItems", JSONArray().apply {
                db.foodItemDao().getAll().forEach { f ->
                    put(JSONObject().apply { put("id", f.id); put("name", f.name); put("isFavorite", f.isFavorite) })
                }
            })
            put("entries", JSONArray().apply {
                db.foodEntryDao().getAll().forEach { e ->
                    put(JSONObject().apply {
                        put("id", e.id); put("name", e.name); put("timeMillis", e.timeMillis)
                        put("category", e.category); put("note", e.note); put("eaten", e.eaten)
                        put("scheduleId", e.scheduleId ?: JSONObject.NULL)
                    })
                }
            })
        }
        val out = context.contentResolver.openOutputStream(uri, "wt") ?: error("Tidak bisa menulis file")
        out.use { it.write(json.toString(2).toByteArray(Charsets.UTF_8)) }
    }

    /** Seluruh file divalidasi dulu; data lama baru diganti kalau file benar-benar valid. */
    suspend fun restore(uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val text = context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                ?: error("File tidak bisa dibaca")
            val json = JSONObject(text)
            require(json.optString("app") == "MakanYuk") { "Bukan file backup MakanYuk" }

            val schedules = json.getJSONArray("schedules").mapObjects {
                val hour = it.getInt("hour")
                val minute = it.getInt("minute")
                require(hour in 0..23 && minute in 0..59) { "Jam jadwal tidak valid" }
                MealSchedule(
                    id = it.getLong("id"), name = it.getString("name"), hour = hour, minute = minute,
                    category = it.getString("category"), message = it.getString("message"),
                    enabled = it.getBoolean("enabled"), daysMask = it.getInt("daysMask"),
                    skipOnSchoolDays = it.getBoolean("skipOnSchoolDays")
                )
            }
            val foods = json.getJSONArray("foodItems").mapObjects {
                FoodItem(id = it.getLong("id"), name = it.getString("name"), isFavorite = it.getBoolean("isFavorite"))
            }
            val entries = json.getJSONArray("entries").mapObjects {
                FoodEntry(
                    id = it.getLong("id"), name = it.getString("name"), timeMillis = it.getLong("timeMillis"),
                    category = it.getString("category"), note = it.getString("note"), eaten = it.getBoolean("eaten"),
                    scheduleId = if (it.isNull("scheduleId")) null else it.getLong("scheduleId")
                )
            }
            val p = json.getJSONObject("prefs")
            val schoolDays = p.getJSONArray("schoolDays").let { a -> (0 until a.length()).map { i -> a.getInt(i) } }
                .filter { it in 1..7 }.toSet()
            val theme = runCatching { ThemeMode.valueOf(p.getString("themeMode")) }.getOrDefault(ThemeMode.SYSTEM)
            val sound = if (p.isNull("soundUri")) null else p.getString("soundUri")

            withContext(NonCancellable) {
                db.withTransaction {
                    db.foodEntryDao().deleteAll()
                    db.mealScheduleDao().deleteAll()
                    db.foodItemDao().deleteAll()
                    db.mealScheduleDao().insertAll(schedules)
                    db.foodItemDao().insertAll(foods)
                    db.foodEntryDao().insertAll(entries)
                }
                prefs.setUserName(p.optString("userName", ""))
                prefs.setThemeMode(theme)
                prefs.setSchoolDays(schoolDays)
                prefs.setNotificationsEnabled(p.optBoolean("notificationsEnabled", true))
                prefs.setSoundUri(sound)
                prefs.setOnboardingDone(true)
                prefs.markSeeded()
            }
        }
    }

    private fun <T> JSONArray.mapObjects(f: (JSONObject) -> T): List<T> =
        (0 until length()).map { f(getJSONObject(it)) }
}
