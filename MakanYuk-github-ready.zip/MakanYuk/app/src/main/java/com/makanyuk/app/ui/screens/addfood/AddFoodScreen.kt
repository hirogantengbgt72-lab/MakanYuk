package com.makanyuk.app.ui.screens.addfood

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.makanyuk.app.AppContainer
import com.makanyuk.app.ui.components.*
import com.makanyuk.app.ui.util.SimpleFactory
import com.makanyuk.app.ui.util.formatDateShort
import com.makanyuk.app.ui.util.formatTime

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddFoodScreen(container: AppContainer, entryId: Long, onBack: () -> Unit) {
    val vm: AddFoodViewModel = viewModel(factory = SimpleFactory { AddFoodViewModel(container, entryId) })
    val suggestions by vm.suggestions.collectAsStateWithLifecycle()
    var showDate by remember { mutableStateOf(false) }
    var showTime by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    if (showDate) {
        AppDatePickerDialog(
            initial = vm.dateTime.toLocalDate(),
            onConfirm = { vm.dateTime = it.atTime(vm.dateTime.toLocalTime()); showDate = false },
            onDismiss = { showDate = false }
        )
    }
    if (showTime) {
        AppTimePickerDialog(
            initial = vm.dateTime.toLocalTime(),
            onConfirm = { vm.dateTime = vm.dateTime.toLocalDate().atTime(it); showTime = false },
            onDismiss = { showTime = false }
        )
    }
    if (confirmDelete) {
        ConfirmDialog(
            title = "Hapus catatan?",
            text = "Catatan makanan ini akan dihapus dari riwayat.",
            confirmLabel = "Hapus",
            onConfirm = { confirmDelete = false; vm.delete(onBack) },
            onDismiss = { confirmDelete = false }
        )
    }

    Scaffold(
        contentWindowInsets = NoInsets,
        topBar = {
            TopAppBar(
                windowInsets = NoInsets,
                title = { Text(if (vm.isEdit) "Edit makanan" else "Tambah makanan") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Kembali")
                    }
                },
                actions = {
                    if (vm.isEdit) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Hapus")
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (!vm.loaded) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                OutlinedTextField(
                    value = vm.name,
                    onValueChange = { vm.name = it; vm.nameError = false },
                    label = { Text("Nama makanan") },
                    isError = vm.nameError,
                    supportingText = { if (vm.nameError) Text("Nama makanan wajib diisi") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    modifier = Modifier.fillMaxWidth()
                )
                if (suggestions.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        suggestions.forEach { s ->
                            SuggestionChip(onClick = { vm.name = s; vm.nameError = false }, label = { Text(s) })
                        }
                    }
                }

                SectionTitle("Kategori")
                CategoryChips(selected = vm.category, onSelected = { vm.category = it })

                SectionTitle("Waktu makan")
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { showDate = true }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.CalendarMonth, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(formatDateShort(vm.dateTime.toLocalDate()))
                    }
                    OutlinedButton(onClick = { showTime = true }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.Schedule, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(formatTime(vm.dateTime.toLocalTime()))
                    }
                }

                OutlinedTextField(
                    value = vm.note,
                    onValueChange = { vm.note = it },
                    label = { Text("Catatan tambahan (opsional)") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Sudah dimakan", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (vm.eaten) "Dihitung dalam progress harian" else "Disimpan sebagai rencana",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Switch(checked = vm.eaten, onCheckedChange = { vm.eaten = it })
                }

                Button(onClick = { vm.save(onBack) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (vm.isEdit) "Simpan perubahan" else "Simpan")
                }
            }
        }
    }
}
