package com.makanyuk.app.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.makanyuk.app.MakanYukApp
import kotlinx.coroutines.launch

/** Menjadwalkan ulang alarm setelah restart, update aplikasi, atau perubahan zona waktu/jam. */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val container = (context.applicationContext as MakanYukApp).container
        val pending = goAsync()
        container.appScope.launch {
            try {
                container.syncReminders()
            } finally {
                pending.finish()
            }
        }
    }
}
