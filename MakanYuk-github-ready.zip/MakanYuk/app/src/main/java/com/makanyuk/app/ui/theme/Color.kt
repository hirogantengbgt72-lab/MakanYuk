package com.makanyuk.app.ui.theme

import androidx.compose.ui.graphics.Color

// Light: pastel hijau + krem
val GreenPrimary = Color(0xFF4E9A71)
val GreenContainer = Color(0xFFC8EBD4)
val OnGreenContainer = Color(0xFF0F3D26)
val Cream = Color(0xFFFFF9EC)
val CreamSurface = Color(0xFFFFFDF6)
val CreamVariant = Color(0xFFF1EBD8)
val WarmAccent = Color(0xFFE8B96A)
val WarmAccentContainer = Color(0xFFFFE9BF)
val InkLight = Color(0xFF1F2A22)

// Dark
val GreenPrimaryDark = Color(0xFF9AD6B2)
val GreenContainerDark = Color(0xFF2B5A40)
val BgDark = Color(0xFF141A16)
val SurfaceDark = Color(0xFF1A211C)
val SurfaceVariantDark = Color(0xFF2A332C)
val InkDark = Color(0xFFE3EAE4)
