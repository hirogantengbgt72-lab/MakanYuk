package com.makanyuk.app.data.repository

import com.makanyuk.app.data.local.dao.FoodItemDao
import com.makanyuk.app.data.local.entity.FoodItem
import kotlinx.coroutines.flow.Flow

class FoodItemRepository(private val dao: FoodItemDao) {
    fun observe(query: String): Flow<List<FoodItem>> =
        if (query.isBlank()) dao.observeAll() else dao.search(query.trim())

    /** Mengembalikan false jika nama sudah ada. */
    suspend fun add(name: String): Boolean = dao.insert(FoodItem(name = name.trim())) != -1L
    suspend fun update(item: FoodItem) = dao.update(item)
    suspend fun toggleFavorite(item: FoodItem) = dao.update(item.copy(isFavorite = !item.isFavorite))
    suspend fun delete(item: FoodItem) = dao.delete(item)
}
