package com.makanyuk.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * daysMask: bit 0 = Senin ... bit 6 = Minggu (DayOfWeek.value - 1). 127 = setiap hari.
 * skipOnSchoolDays: jika true, jadwal dilewati pada hari yang ditandai sebagai hari sekolah.
 */
@Entity(tableName = "meal_schedule")
data class MealSchedule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val hour: Int,
    val minute: Int,
    val category: String,
    val message: String,
    val enabled: Boolean = true,
    val daysMask: Int = 127,
    val skipOnSchoolDays: Boolean = false
)
