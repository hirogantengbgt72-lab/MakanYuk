package com.makanyuk.app.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.makanyuk.app.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "user_prefs")

data class UserPreferences(
    val userName: String = "",
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val schoolDays: Set<Int> = DEFAULT_SCHOOL_DAYS, // 1 = Senin ... 7 = Minggu
    val notificationsEnabled: Boolean = true,
    val soundUri: String? = null, // null = suara notifikasi bawaan
    val onboardingDone: Boolean = false
) {
    companion object {
        val DEFAULT_SCHOOL_DAYS = setOf(1, 2, 3, 4, 5, 6)
    }
}

class UserPrefsRepository(private val context: Context) {

    private object Keys {
        val NAME = stringPreferencesKey("user_name")
        val THEME = stringPreferencesKey("theme_mode")
        val SCHOOL_DAYS = stringSetPreferencesKey("school_days")
        val NOTIF = booleanPreferencesKey("notifications_enabled")
        val SOUND = stringPreferencesKey("sound_uri")
        val ONBOARDING = booleanPreferencesKey("onboarding_done")
        val SEEDED = booleanPreferencesKey("seeded")
    }

    val flow: Flow<UserPreferences> = context.dataStore.data.map { p ->
        UserPreferences(
            userName = p[Keys.NAME] ?: "",
            themeMode = p[Keys.THEME]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM,
            schoolDays = p[Keys.SCHOOL_DAYS]?.mapNotNull { it.toIntOrNull() }?.toSet()
                ?: UserPreferences.DEFAULT_SCHOOL_DAYS,
            notificationsEnabled = p[Keys.NOTIF] ?: true,
            soundUri = p[Keys.SOUND],
            onboardingDone = p[Keys.ONBOARDING] ?: false
        )
    }

    suspend fun current(): UserPreferences = flow.first()

    suspend fun setUserName(v: String) = context.dataStore.edit { it[Keys.NAME] = v.trim() }.let {}
    suspend fun setThemeMode(v: ThemeMode) = context.dataStore.edit { it[Keys.THEME] = v.name }.let {}
    suspend fun setSchoolDays(v: Set<Int>) =
        context.dataStore.edit { it[Keys.SCHOOL_DAYS] = v.map { d -> d.toString() }.toSet() }.let {}
    suspend fun setNotificationsEnabled(v: Boolean) = context.dataStore.edit { it[Keys.NOTIF] = v }.let {}
    suspend fun setSoundUri(v: String?) = context.dataStore.edit {
        if (v == null) it.remove(Keys.SOUND) else it[Keys.SOUND] = v
    }.let {}
    suspend fun setOnboardingDone(v: Boolean) = context.dataStore.edit { it[Keys.ONBOARDING] = v }.let {}

    suspend fun isSeeded(): Boolean = context.dataStore.data.first()[Keys.SEEDED] ?: false
    suspend fun markSeeded() = context.dataStore.edit { it[Keys.SEEDED] = true }.let {}

    /** Dipakai oleh fitur reset data. */
    suspend fun clearAll() = context.dataStore.edit { it.clear() }.let {}
}
