package com.makanyuk.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.makanyuk.app.domain.model.ThemeMode

private val LightColors = lightColorScheme(
    primary = GreenPrimary, onPrimary = Color.White,
    primaryContainer = GreenContainer, onPrimaryContainer = OnGreenContainer,
    secondary = Color(0xFF6B8F77), onSecondary = Color.White,
    secondaryContainer = CreamVariant, onSecondaryContainer = InkLight,
    tertiary = WarmAccent, onTertiary = InkLight,
    tertiaryContainer = WarmAccentContainer, onTertiaryContainer = InkLight,
    background = Cream, onBackground = InkLight,
    surface = CreamSurface, onSurface = InkLight,
    surfaceVariant = CreamVariant, onSurfaceVariant = Color(0xFF4A554D),
    outline = Color(0xFF8A958C)
)

private val DarkColors = darkColorScheme(
    primary = GreenPrimaryDark, onPrimary = Color(0xFF0D3A22),
    primaryContainer = GreenContainerDark, onPrimaryContainer = GreenContainer,
    secondary = Color(0xFFA9C7B3), onSecondary = Color(0xFF14301F),
    secondaryContainer = SurfaceVariantDark, onSecondaryContainer = InkDark,
    tertiary = Color(0xFFE8C98F), onTertiary = Color(0xFF3A2A06),
    tertiaryContainer = Color(0xFF5A4620), onTertiaryContainer = WarmAccentContainer,
    background = BgDark, onBackground = InkDark,
    surface = SurfaceDark, onSurface = InkDark,
    surfaceVariant = SurfaceVariantDark, onSurfaceVariant = Color(0xFFBBC6BE),
    outline = Color(0xFF86918A)
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun MakanYukTheme(themeMode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
