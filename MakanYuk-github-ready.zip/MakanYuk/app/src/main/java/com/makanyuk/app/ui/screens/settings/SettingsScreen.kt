package com.makanyuk.app.ui.screens.settings

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.IntentCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.makanyuk.app.AppContainer
import com.makanyuk.app.data.prefs.UserPreferences
import com.makanyuk.app.domain.model.ThemeMode
import com.makanyuk.app.notification.NotificationHelper
import com.makanyuk.app.ui.components.AppCard
import com.makanyuk.app.ui.components.ConfirmDialog
import com.makanyuk.app.ui.components.SectionTitle
import com.makanyuk.app.ui.util.DayLabels
import kotlinx.coroutines.launch
import java.time.LocalDate

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    container: AppContainer,
    onOpenSchedule: () -> Unit,
    onOpenFoods: () -> Unit,
    onReset: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val prefs by container.prefs.flow.collectAsStateWithLifecycle(initialValue = UserPreferences())

    var notificationsAllowed by remember { mutableStateOf(container.notifications.areNotificationsAllowed()) }
    var exactAllowed by remember { mutableStateOf(container.scheduler.canScheduleExact()) }
    var showName by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }
    var pendingRestore by remember { mutableStateOf<Uri?>(null) }

    // Status izin bisa berubah saat pengguna kembali dari layar pengaturan sistem.
    LifecycleResumeEffect(Unit) {
        notificationsAllowed = container.notifications.areNotificationsAllowed()
        exactAllowed = container.scheduler.canScheduleExact()
        onPauseOrDispose { }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        notificationsAllowed = container.notifications.areNotificationsAllowed()
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            val result = runCatching { container.backup.export(uri) }
            snackbar.showSnackbar(if (result.isSuccess) "Backup berhasil disimpan" else "Backup gagal disimpan")
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingRestore = uri
    }
    val soundLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val picked = result.data?.let {
                IntentCompat.getParcelableExtra(it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            }
            val value = when {
                picked == null -> NotificationHelper.SOUND_SILENT
                picked == RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) -> null
                else -> picked.toString()
            }
            scope.launch { container.prefs.setSoundUri(value) }
        }
    }

    if (showName) {
        TextInputDialog(
            title = "Nama kamu",
            label = "Nama panggilan",
            initial = prefs.userName,
            onDismiss = { showName = false },
            onSave = { scope.launch { container.prefs.setUserName(it) }; showName = false }
        )
    }
    pendingRestore?.let { uri ->
        ConfirmDialog(
            title = "Restore data?",
            text = "Semua data saat ini akan diganti dengan isi file backup.",
            confirmLabel = "Restore",
            onConfirm = {
                pendingRestore = null
                scope.launch {
                    val result = container.backup.restore(uri)
                    snackbar.showSnackbar(
                        if (result.isSuccess) "Data berhasil dipulihkan"
                        else "File backup tidak valid. Data tidak diubah."
                    )
                }
            },
            onDismiss = { pendingRestore = null }
        )
    }
    if (showReset) {
        ConfirmDialog(
            title = "Reset semua data?",
            text = "Semua catatan makan, jadwal, daftar makanan, dan pengaturan akan dihapus lalu dikembalikan ke awal. Tindakan ini tidak bisa dibatalkan.",
            confirmLabel = "Reset",
            onConfirm = {
                showReset = false
                scope.launch { container.resetAll(); onReset() }
            },
            onDismiss = { showReset = false }
        )
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Pengaturan", style = MaterialTheme.typography.headlineMedium)

            SectionTitle("Profil")
            AppCard {
                SettingRow(
                    title = "Nama",
                    subtitle = prefs.userName.ifBlank { "Belum diisi" },
                    onClick = { showName = true }
                )
            }

            SectionTitle("Jadwal")
            AppCard {
                SettingRow(
                    title = "Jadwal makan",
                    subtitle = "Atur jam, hari, dan pengingat",
                    onClick = onOpenSchedule
                )
                Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Hari sekolah", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Pengingat sarapan di rumah dilewati pada hari sekolah. Hari lain mengikuti jadwal santai.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        DayLabels.forEachIndexed { index, label ->
                            val day = index + 1
                            FilterChip(
                                selected = day in prefs.schoolDays,
                                onClick = {
                                    val updated = if (day in prefs.schoolDays) prefs.schoolDays - day else prefs.schoolDays + day
                                    scope.launch { container.prefs.setSchoolDays(updated) }
                                },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            SectionTitle("Notifikasi")
            AppCard {
                SettingRow(
                    title = "Aktifkan notifikasi",
                    subtitle = "Pengingat sesuai jadwal makan",
                    trailing = {
                        Switch(
                            checked = prefs.notificationsEnabled,
                            onCheckedChange = { on ->
                                scope.launch { container.prefs.setNotificationsEnabled(on) }
                                if (on && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notificationsAllowed) {
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            }
                        )
                    }
                )
                if (prefs.notificationsEnabled && !notificationsAllowed) {
                    SettingRow(
                        title = "Izin notifikasi belum aktif",
                        subtitle = "Ketuk untuk membuka pengaturan notifikasi",
                        onClick = {
                            context.startActivity(
                                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                    .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                            )
                        }
                    )
                }
                if (prefs.notificationsEnabled && !exactAllowed) {
                    SettingRow(
                        title = "Alarm tepat waktu belum diizinkan",
                        subtitle = "Tanpa izin ini, pengingat bisa terlambat. Ketuk untuk mengizinkan.",
                        onClick = { container.scheduler.exactAlarmSettingsIntent()?.let { context.startActivity(it) } }
                    )
                }
                SettingRow(
                    title = "Suara notifikasi",
                    subtitle = remember(prefs.soundUri) { soundLabel(context, prefs.soundUri) },
                    onClick = {
                        val current = prefs.soundUri
                        val existing: Uri? = when (current) {
                            null -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                            NotificationHelper.SOUND_SILENT -> null
                            else -> Uri.parse(current)
                        }
                        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, existing)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Suara notifikasi")
                        }
                        soundLauncher.launch(intent)
                    }
                )
                SettingRow(
                    title = "Tes notifikasi",
                    subtitle = "Munculkan contoh pengingat sekarang",
                    onClick = {
                        if (container.notifications.areNotificationsAllowed()) {
                            container.notifications.showTest(prefs.soundUri)
                        } else {
                            scope.launch { snackbar.showSnackbar("Izin notifikasi belum aktif") }
                        }
                    }
                )
            }

            SectionTitle("Tampilan")
            AppCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tema", style = MaterialTheme.typography.titleMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            ThemeMode.SYSTEM to "Ikuti sistem",
                            ThemeMode.LIGHT to "Terang",
                            ThemeMode.DARK to "Gelap"
                        ).forEach { (mode, label) ->
                            FilterChip(
                                selected = prefs.themeMode == mode,
                                onClick = { scope.launch { container.prefs.setThemeMode(mode) } },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            SectionTitle("Makanan dan data")
            AppCard {
                SettingRow(title = "Daftar makanan", subtitle = "Kelola makanan, favorit, dan pencarian", onClick = onOpenFoods)
                SettingRow(
                    title = "Backup data",
                    subtitle = "Simpan semua data ke file di HP",
                    onClick = { exportLauncher.launch("makanyuk-backup-${LocalDate.now()}.json") }
                )
                SettingRow(
                    title = "Restore data",
                    subtitle = "Pulihkan dari file backup",
                    onClick = { importLauncher.launch(arrayOf("*/*")) }
                )
                SettingRow(
                    title = "Reset data",
                    subtitle = "Hapus semua data dan mulai dari awal",
                    onClick = { showReset = true }
                )
            }

            Text(
                "MakanYuk 1.0 • Tanpa akun, tanpa iklan. Data hanya tersimpan di HP ini.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }
        SnackbarHost(snackbar, modifier = Modifier.align(Alignment.BottomCenter))
    }
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String? = null,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium)
        }
        trailing?.invoke()
    }
}

@Composable
private fun TextInputDialog(
    title: String,
    label: String,
    initial: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(label) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = { TextButton(onClick = { onSave(text) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

private fun soundLabel(context: Context, soundUri: String?): String = when (soundUri) {
    null -> "Bawaan"
    NotificationHelper.SOUND_SILENT -> "Senyap"
    else -> runCatching {
        RingtoneManager.getRingtone(context, Uri.parse(soundUri))?.getTitle(context)
    }.getOrNull() ?: "Nada pilihan"
}
