package com.makanyuk.app.domain

import com.makanyuk.app.data.local.entity.MealSchedule
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.LocalTime
import kotlin.math.abs

/** Menentukan jadwal mana yang aktif pada hari tertentu (hari sekolah vs hari santai). */
object ScheduleResolver {

    fun isActiveOn(s: MealSchedule, day: DayOfWeek, schoolDays: Set<Int>): Boolean {
        if (!s.enabled) return false
        val bit = 1 shl (day.value - 1)
        if ((s.daysMask and bit) == 0) return false
        if (s.skipOnSchoolDays && day.value in schoolDays) return false
        return true
    }

    fun forDay(all: List<MealSchedule>, day: DayOfWeek, schoolDays: Set<Int>): List<MealSchedule> =
        all.filter { isActiveOn(it, day, schoolDays) }.sortedBy { it.hour * 60 + it.minute }

    /** Pengingat berikutnya setelah [now], mencari sampai 7 hari ke depan. */
    fun nextOccurrence(
        all: List<MealSchedule>,
        schoolDays: Set<Int>,
        now: LocalDateTime
    ): Pair<MealSchedule, LocalDateTime>? {
        for (offset in 0..7) {
            val date = now.toLocalDate().plusDays(offset.toLong())
            for (s in forDay(all, date.dayOfWeek, schoolDays)) {
                val time = date.atTime(s.hour, s.minute)
                if (time.isAfter(now)) return s to time
            }
        }
        return null
    }

    fun minutesOfDay(s: MealSchedule): Int = s.hour * 60 + s.minute

    /** Jadwal yang belum selesai dengan kategori sama dan waktu terdekat, untuk dikaitkan ke catatan baru. */
    fun autoLink(active: List<MealSchedule>, doneIds: Set<Long>, category: String, time: LocalTime): Long? =
        active.filter { it.category == category && it.id !in doneIds }
            .minByOrNull { abs(minutesOfDay(it) - (time.hour * 60 + time.minute)) }
            ?.id
}
