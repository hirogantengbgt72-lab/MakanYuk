package com.makanyuk.app.ui.screens.schedule

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.makanyuk.app.AppContainer
import com.makanyuk.app.data.local.entity.MealSchedule
import com.makanyuk.app.domain.model.MealCategory
import com.makanyuk.app.ui.components.AppCard
import com.makanyuk.app.ui.util.*

@Composable
fun ScheduleScreen(container: AppContainer, onOpenSettings: () -> Unit) {
    val vm: ScheduleViewModel = viewModel(factory = SimpleFactory { ScheduleViewModel(container) })
    val schedules by vm.schedules.collectAsStateWithLifecycle()
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<MealSchedule?>(null) }

    editing?.let { item ->
        ScheduleEditDialog(
            initial = item,
            onDismiss = { editing = null },
            onSave = { vm.save(it); editing = null },
            onDelete = if (item.id != 0L) ({ vm.delete(item); editing = null }) else null
        )
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Jadwal makan", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        "Sentuh jadwal untuk mengubahnya. Notifikasi mengikuti jadwal yang aktif.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            item {
                AppCard(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Hari sekolah", style = MaterialTheme.typography.titleMedium)
                            val days = prefs.schoolDays.sorted().joinToString(", ") { DayLabels[it - 1] }
                            Text(
                                if (days.isEmpty()) "Tidak ada hari sekolah" else "$days • hari lain santai",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        TextButton(onClick = onOpenSettings) { Text("Atur") }
                    }
                }
            }
            if (schedules.isEmpty()) {
                item { Text("Belum ada jadwal. Tekan tombol tambah.", style = MaterialTheme.typography.bodyLarge) }
            }
            items(schedules, key = { it.id }) { s ->
                AppCard {
                    Row(
                        Modifier.fillMaxWidth().clickable { editing = s }.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(categoryEmoji(s.category), fontSize = 26.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${formatTime(s.hour, s.minute)} • ${daysSummary(s.daysMask)}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            if (s.skipOnSchoolDays) {
                                Text("Dilewati di hari sekolah", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Switch(checked = s.enabled, onCheckedChange = { vm.setEnabled(s, it) })
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = {
                editing = MealSchedule(
                    name = "", hour = 12, minute = 0,
                    category = MealCategory.MAKAN_SIANG.name, message = ""
                )
            },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
            text = { Text("Tambah jadwal") }
        )
    }
}
