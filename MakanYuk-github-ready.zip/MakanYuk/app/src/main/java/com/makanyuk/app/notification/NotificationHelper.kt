package com.makanyuk.app.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.makanyuk.app.MainActivity
import com.makanyuk.app.R

class NotificationHelper(private val context: Context) {

    private val nm: NotificationManager = context.getSystemService(NotificationManager::class.java)

    companion object {
        const val SOUND_SILENT = "silent"
        private const val PREFIX = "meal_reminders_"
    }

    private fun channelId(soundUri: String?): String = when (soundUri) {
        null -> PREFIX + "default"
        SOUND_SILENT -> PREFIX + "silent"
        else -> PREFIX + soundUri.hashCode()
    }

    /**
     * Suara channel tidak bisa diubah setelah dibuat, jadi setiap pilihan suara
     * memakai channel sendiri dan channel lama dihapus.
     * soundUri: null = bawaan, SOUND_SILENT = senyap, selain itu = URI nada pilihan.
     */
    fun ensureChannel(soundUri: String?): String {
        val id = channelId(soundUri)
        if (nm.getNotificationChannel(id) == null) {
            val channel = NotificationChannel(id, "Pengingat makan", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Pengingat jadwal makan harian"
                enableVibration(soundUri != SOUND_SILENT)
                if (soundUri == SOUND_SILENT) {
                    setSound(null, null)
                } else {
                    val uri = soundUri?.let { Uri.parse(it) }
                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    setSound(
                        uri,
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                }
            }
            nm.createNotificationChannel(channel)
        }
        nm.notificationChannels
            .filter { it.id.startsWith(PREFIX) && it.id != id }
            .forEach { nm.deleteNotificationChannel(it.id) }
        return id
    }

    fun areNotificationsAllowed(): Boolean = NotificationManagerCompat.from(context).areNotificationsEnabled()

    fun show(notificationId: Int, text: String, soundUri: String?) {
        if (!areNotificationsAllowed()) return
        val channelId = ensureChannel(soundUri)
        val openApp = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("MakanYuk")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .build()
        nm.notify(notificationId, notification)
    }

    /** Untuk tombol "Tes notifikasi" di Pengaturan. */
    fun showTest(soundUri: String?) = show(0, "Ini contoh pengingat. Jangan lupa makan ya!", soundUri)
}
