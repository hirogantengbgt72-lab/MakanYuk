package com.makanyuk.app.data.repository

import com.makanyuk.app.data.local.dao.FoodEntryDao
import com.makanyuk.app.data.local.entity.FoodEntry

class FoodEntryRepository(private val dao: FoodEntryDao) {
    fun observeBetween(start: Long, end: Long) = dao.observeBetween(start, end)
    fun observeAll() = dao.observeAll()
    suspend fun getById(id: Long) = dao.getById(id)
    suspend fun save(entry: FoodEntry): Long =
        if (entry.id == 0L) dao.insert(entry) else { dao.update(entry); entry.id }
    suspend fun delete(entry: FoodEntry) = dao.delete(entry)
}
