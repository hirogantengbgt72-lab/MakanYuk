package com.makanyuk.app.domain.model

enum class ThemeMode { SYSTEM, LIGHT, DARK }
