package com.makanyuk.app

import android.content.Context
import androidx.room.Room
import com.makanyuk.app.data.backup.BackupManager
import com.makanyuk.app.data.local.AppDatabase
import com.makanyuk.app.data.local.MIGRATION_1_2
import com.makanyuk.app.data.local.Seeder
import com.makanyuk.app.data.prefs.UserPrefsRepository
import com.makanyuk.app.data.repository.FoodEntryRepository
import com.makanyuk.app.data.repository.FoodItemRepository
import com.makanyuk.app.data.repository.MealScheduleRepository
import com.makanyuk.app.notification.NotificationHelper
import com.makanyuk.app.notification.ReminderScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

/** Dependency injection manual (tanpa Hilt). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: AppDatabase =
        Room.databaseBuilder(appContext, AppDatabase::class.java, "makanyuk.db")
            .addMigrations(MIGRATION_1_2)
            .build()

    val prefs = UserPrefsRepository(appContext)
    val foodEntries = FoodEntryRepository(database.foodEntryDao())
    val schedules = MealScheduleRepository(database.mealScheduleDao())
    val foodItems = FoodItemRepository(database.foodItemDao())

    val backup = BackupManager(appContext, database, prefs)
    val notifications = NotificationHelper(appContext)
    val scheduler = ReminderScheduler(appContext)

    fun init() {
        // Isi data bawaan satu kali (peluncuran pertama).
        appScope.launch {
            if (!prefs.isSeeded()) {
                Seeder.seed(database)
                prefs.markSeeded()
            }
        }
        // Setiap jadwal atau pengaturan notifikasi berubah, alarm diselaraskan otomatis.
        appScope.launch {
            combine(schedules.observeAll(), prefs.flow) { list, p -> list to p }
                .distinctUntilChanged { old, new ->
                    old.first == new.first &&
                        old.second.notificationsEnabled == new.second.notificationsEnabled &&
                        old.second.schoolDays == new.second.schoolDays &&
                        old.second.soundUri == new.second.soundUri
                }
                .collect { (list, p) ->
                    notifications.ensureChannel(p.soundUri)
                    scheduler.sync(list, p)
                }
        }
    }

    /** Dipakai BootReceiver. */
    suspend fun syncReminders() {
        val p = prefs.current()
        notifications.ensureChannel(p.soundUri)
        scheduler.sync(schedules.getAll(), p)
    }

    /** Hapus semua data dan pengaturan, lalu isi ulang jadwal & makanan bawaan. */
    suspend fun resetAll() = withContext(Dispatchers.IO + NonCancellable) {
        database.clearAllTables()
        prefs.clearAll()
        Seeder.seed(database)
        prefs.markSeeded()
    }
}
