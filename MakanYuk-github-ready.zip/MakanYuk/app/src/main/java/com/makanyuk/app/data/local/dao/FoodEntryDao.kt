package com.makanyuk.app.data.local.dao

import androidx.room.*
import com.makanyuk.app.data.local.entity.FoodEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface FoodEntryDao {
    @Insert suspend fun insert(entry: FoodEntry): Long
    @Insert suspend fun insertAll(entries: List<FoodEntry>)
    @Update suspend fun update(entry: FoodEntry)
    @Delete suspend fun delete(entry: FoodEntry)

    @Query("SELECT * FROM food_entry WHERE id = :id")
    suspend fun getById(id: Long): FoodEntry?

    @Query("SELECT * FROM food_entry WHERE timeMillis >= :start AND timeMillis < :end ORDER BY timeMillis ASC")
    fun observeBetween(start: Long, end: Long): Flow<List<FoodEntry>>

    @Query("SELECT * FROM food_entry ORDER BY timeMillis DESC")
    fun observeAll(): Flow<List<FoodEntry>>

    @Query("SELECT * FROM food_entry")
    suspend fun getAll(): List<FoodEntry>

    @Query("DELETE FROM food_entry")
    suspend fun deleteAll()
}
