package com.makanyuk.app.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.padding
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.makanyuk.app.AppContainer
import com.makanyuk.app.data.prefs.UserPreferences
import com.makanyuk.app.ui.screens.SplashScreen
import com.makanyuk.app.ui.screens.addfood.AddFoodScreen
import com.makanyuk.app.ui.screens.calendar.CalendarScreen
import com.makanyuk.app.ui.screens.foods.FoodListScreen
import com.makanyuk.app.ui.screens.history.HistoryScreen
import com.makanyuk.app.ui.screens.home.HomeScreen
import com.makanyuk.app.ui.screens.onboarding.OnboardingScreen
import com.makanyuk.app.ui.screens.schedule.ScheduleScreen
import com.makanyuk.app.ui.screens.settings.SettingsScreen

@Composable
fun MakanYukRoot(container: AppContainer, prefs: UserPreferences?) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val showBottomBar = currentRoute in Routes.bottomBarRoutes

    val navigateTab: (String) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(Routes.HOME) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        bottomBar = {
            if (showBottomBar) MakanYukBottomBar(currentRoute, navigateTab)
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Routes.SPLASH,
            modifier = Modifier.padding(padding),
            enterTransition = { fadeIn(tween(250)) + slideInHorizontally(tween(250)) { it / 12 } },
            exitTransition = { fadeOut(tween(200)) },
            popEnterTransition = { fadeIn(tween(250)) },
            popExitTransition = { fadeOut(tween(200)) + slideOutHorizontally(tween(250)) { it / 12 } }
        ) {
            composable(Routes.SPLASH) {
                SplashScreen(ready = prefs != null) {
                    val dest = if (prefs?.onboardingDone == true) Routes.HOME else Routes.ONBOARDING
                    navController.navigate(dest) { popUpTo(Routes.SPLASH) { inclusive = true } }
                }
            }
            composable(Routes.ONBOARDING) {
                OnboardingScreen(container) {
                    navController.navigate(Routes.HOME) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                }
            }
            composable(Routes.HOME) {
                HomeScreen(
                    container = container,
                    onAddFood = { navController.navigate(Routes.addFood()) },
                    onEditEntry = { navController.navigate(Routes.addFood(it)) }
                )
            }
            composable(Routes.SCHEDULE) {
                ScheduleScreen(container, onOpenSettings = { navigateTab(Routes.SETTINGS) })
            }
            composable(Routes.HISTORY) {
                HistoryScreen(container, onEditEntry = { navController.navigate(Routes.addFood(it)) })
            }
            composable(Routes.CALENDAR) {
                CalendarScreen(container, onEditEntry = { navController.navigate(Routes.addFood(it)) })
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    container = container,
                    onOpenSchedule = { navigateTab(Routes.SCHEDULE) },
                    onOpenFoods = { navController.navigate(Routes.FOODS) },
                    onReset = {
                        // Kosongkan seluruh back stack, lalu mulai lagi dari splash -> onboarding.
                        navController.navigate(Routes.SPLASH) {
                            popUpTo(navController.graph.id) { inclusive = true }
                        }
                    }
                )
            }
            composable(Routes.FOODS) {
                FoodListScreen(container, onBack = { navController.popBackStack() })
            }
            composable(
                route = Routes.ADD_FOOD,
                arguments = listOf(navArgument(Routes.ARG_ENTRY_ID) {
                    type = NavType.LongType
                    defaultValue = -1L
                })
            ) { entry ->
                val entryId = entry.arguments?.getLong(Routes.ARG_ENTRY_ID) ?: -1L
                AddFoodScreen(container, entryId, onBack = { navController.popBackStack() })
            }
        }
    }
}
