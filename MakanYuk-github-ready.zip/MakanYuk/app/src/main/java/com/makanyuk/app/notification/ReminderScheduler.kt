package com.makanyuk.app.notification

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.net.Uri
import com.makanyuk.app.data.local.entity.MealSchedule
import com.makanyuk.app.data.prefs.UserPreferences
import com.makanyuk.app.domain.ScheduleResolver
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Satu alarm per jadwal. Setelah alarm berbunyi, ReminderReceiver menjadwalkan
 * kemunculan berikutnya, sehingga pengingat berulang tanpa batas.
 */
class ReminderScheduler(private val context: Context) {

    private val alarmManager: AlarmManager = context.getSystemService(AlarmManager::class.java)
    private var scheduledIds: Set<Long> = emptySet()

    companion object {
        const val ACTION_REMIND = "com.makanyuk.app.ACTION_REMIND"
        const val EXTRA_SCHEDULE_ID = "schedule_id"
    }

    fun canScheduleExact(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()

    /** Intent ke layar izin "Alarm & pengingat" (Android 12+), untuk dipakai di Pengaturan. */
    fun exactAlarmSettingsIntent(): Intent? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}"))
        else null

    private fun pendingIntent(id: Long, flag: Int): PendingIntent? =
        PendingIntent.getBroadcast(
            context,
            id.toInt(),
            Intent(context, ReminderReceiver::class.java)
                .setAction(ACTION_REMIND)
                .putExtra(EXTRA_SCHEDULE_ID, id),
            flag or PendingIntent.FLAG_IMMUTABLE
        )

    fun schedule(s: MealSchedule, schoolDays: Set<Int>, now: LocalDateTime = LocalDateTime.now()) {
        val next = ScheduleResolver.nextOccurrence(listOf(s), schoolDays, now)
        if (next == null) {
            cancel(s.id)
            return
        }
        val triggerAt = next.second.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val pi = pendingIntent(s.id, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        try {
            if (canScheduleExact()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        } catch (e: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    fun cancel(id: Long) {
        pendingIntent(id, PendingIntent.FLAG_NO_CREATE)?.let {
            alarmManager.cancel(it)
            it.cancel()
        }
    }

    /** Menyelaraskan semua alarm dengan jadwal dan pengaturan saat ini. */
    @Synchronized
    fun sync(schedules: List<MealSchedule>, prefs: UserPreferences) {
        schedules.forEach { s ->
            if (prefs.notificationsEnabled && s.enabled) schedule(s, prefs.schoolDays) else cancel(s.id)
        }
        val currentIds = schedules.map { it.id }.toSet()
        (scheduledIds - currentIds).forEach { cancel(it) } // jadwal yang sudah dihapus
        scheduledIds = currentIds
    }
}
