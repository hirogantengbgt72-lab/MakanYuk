package com.makanyuk.app.ui.screens.schedule

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.makanyuk.app.AppContainer
import com.makanyuk.app.data.local.entity.MealSchedule
import com.makanyuk.app.data.prefs.UserPreferences
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Alarm diselaraskan otomatis oleh AppContainer setiap daftar jadwal berubah. */
class ScheduleViewModel(private val container: AppContainer) : ViewModel() {

    val schedules: StateFlow<List<MealSchedule>> = container.schedules.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val prefs: StateFlow<UserPreferences> = container.prefs.flow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UserPreferences())

    fun save(schedule: MealSchedule) {
        viewModelScope.launch { container.schedules.save(schedule) }
    }

    fun delete(schedule: MealSchedule) {
        viewModelScope.launch { container.schedules.delete(schedule) }
    }

    fun setEnabled(schedule: MealSchedule, enabled: Boolean) = save(schedule.copy(enabled = enabled))
}
