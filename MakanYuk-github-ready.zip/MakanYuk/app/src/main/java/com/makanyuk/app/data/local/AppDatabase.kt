package com.makanyuk.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.makanyuk.app.data.local.dao.FoodEntryDao
import com.makanyuk.app.data.local.dao.FoodItemDao
import com.makanyuk.app.data.local.dao.MealScheduleDao
import com.makanyuk.app.data.local.entity.FoodEntry
import com.makanyuk.app.data.local.entity.FoodItem
import com.makanyuk.app.data.local.entity.MealSchedule

@Database(
    entities = [FoodEntry::class, MealSchedule::class, FoodItem::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun foodEntryDao(): FoodEntryDao
    abstract fun mealScheduleDao(): MealScheduleDao
    abstract fun foodItemDao(): FoodItemDao
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE food_entry ADD COLUMN scheduleId INTEGER")
    }
}
