package com.makanyuk.app.ui.screens.onboarding

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.makanyuk.app.AppContainer
import com.makanyuk.app.data.prefs.UserPreferences
import com.makanyuk.app.ui.util.DayLabels
import kotlinx.coroutines.launch

private const val PAGE_COUNT = 3

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(container: AppContainer, onFinished: () -> Unit) {
    val scope = rememberCoroutineScope()
    val pagerState = rememberPagerState(pageCount = { PAGE_COUNT })
    var name by remember { mutableStateOf("") }
    var schoolDays by remember { mutableStateOf(UserPreferences.DEFAULT_SCHOOL_DAYS) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { page ->
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (page) {
                    0 -> {
                        Text("🍚", fontSize = 80.sp)
                        Spacer(Modifier.height(16.dp))
                        Text("Halo! Selamat datang di MakanYuk", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Pengingat makan pribadi untuk menjaga jadwal makanmu tetap teratur. " +
                                "Tanpa akun dan tanpa internet. Datamu hanya tersimpan di HP ini.",
                            style = MaterialTheme.typography.bodyLarge,
                            textAlign = TextAlign.Center
                        )
                    }
                    1 -> {
                        Text("🎒", fontSize = 80.sp)
                        Spacer(Modifier.height(16.dp))
                        Text("Hari sekolahmu", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Pilih hari kamu berangkat sekolah. Pengingat sarapan di rumah dimatikan di hari itu " +
                                "karena kamu makan di kantin. Hari lain tetap mengikuti jadwal santai.",
                            style = MaterialTheme.typography.bodyLarge,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(16.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            DayLabels.forEachIndexed { index, label ->
                                val day = index + 1
                                FilterChip(
                                    selected = day in schoolDays,
                                    onClick = {
                                        schoolDays = if (day in schoolDays) schoolDays - day else schoolDays + day
                                    },
                                    label = { Text(label) }
                                )
                            }
                        }
                        Text(
                            "Bisa diubah kapan saja di Pengaturan.",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                    else -> {
                        Text("👋", fontSize = 80.sp)
                        Spacer(Modifier.height(16.dp))
                        Text("Kenalan dulu, yuk", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(16.dp))
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Nama panggilan (opsional)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            Spacer(Modifier.height(16.dp))
                            Text(
                                "Agar pengingat bisa muncul, izinkan notifikasi.",
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) {
                                Text("Izinkan notifikasi")
                            }
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(PAGE_COUNT) { i ->
                    Box(
                        Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                if (i == pagerState.currentPage) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                            )
                    )
                }
            }
            val isLast = pagerState.currentPage == PAGE_COUNT - 1
            Button(onClick = {
                scope.launch {
                    if (isLast) {
                        container.prefs.setUserName(name)
                        container.prefs.setSchoolDays(schoolDays)
                        container.prefs.setOnboardingDone(true)
                        onFinished()
                    } else {
                        pagerState.animateScrollToPage(pagerState.currentPage + 1)
                    }
                }
            }) { Text(if (isLast) "Mulai" else "Lanjut") }
        }
    }
}
