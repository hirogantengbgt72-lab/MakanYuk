package com.makanyuk.app.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.makanyuk.app.AppContainer
import com.makanyuk.app.MakanYukApp
import com.makanyuk.app.domain.ScheduleResolver
import kotlinx.coroutines.launch
import java.time.LocalDate

class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(ReminderScheduler.EXTRA_SCHEDULE_ID, -1L)
        if (id < 0) return
        val container = (context.applicationContext as MakanYukApp).container
        val pending = goAsync()
        container.appScope.launch {
            try {
                process(container, id)
            } finally {
                pending.finish()
            }
        }
    }

    private suspend fun process(container: AppContainer, id: Long) {
        // Jadwal sudah dihapus: abaikan dan jangan dijadwalkan ulang.
        val schedule = container.schedules.getById(id) ?: return
        val prefs = container.prefs.current()
        if (!prefs.notificationsEnabled || !schedule.enabled) return

        val today = LocalDate.now().dayOfWeek
        if (ScheduleResolver.isActiveOn(schedule, today, prefs.schoolDays)) {
            container.notifications.show(id.toInt(), schedule.message, prefs.soundUri)
        }
        container.scheduler.schedule(schedule, prefs.schoolDays)
    }
}
