package com.makanyuk.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.makanyuk.app.data.local.entity.FoodEntry
import com.makanyuk.app.domain.model.MealCategory
import com.makanyuk.app.ui.util.formatTime
import com.makanyuk.app.ui.util.millisToDateTime

@Composable
fun FoodEntryRow(entry: FoodEntry, onClick: () -> Unit, onDelete: (() -> Unit)? = null) {
    val time = millisToDateTime(entry.timeMillis).toLocalTime()
    val category = MealCategory.fromName(entry.category)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = if (onDelete == null) 16.dp else 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(category.emoji(), fontSize = 24.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(entry.name, style = MaterialTheme.typography.titleMedium)
            val status = if (entry.eaten) "" else " • Rencana"
            Text("${formatTime(time)} • ${category.label}$status", style = MaterialTheme.typography.bodyMedium)
            if (entry.note.isNotBlank()) {
                Text(entry.note, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (onDelete != null) {
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, contentDescription = "Hapus") }
        }
    }
}

private fun MealCategory.emoji(): String = com.makanyuk.app.ui.util.categoryEmoji(this.name)
