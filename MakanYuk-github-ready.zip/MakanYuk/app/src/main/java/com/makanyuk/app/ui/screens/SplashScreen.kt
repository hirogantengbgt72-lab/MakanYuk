package com.makanyuk.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Splash minimal 1,2 detik; baru lanjut setelah preferensi selesai dimuat. */
@Composable
fun SplashScreen(ready: Boolean, onFinished: () -> Unit) {
    val currentOnFinished by rememberUpdatedState(onFinished)
    var minTimePassed by remember { mutableStateOf(false) }
    val scale = remember { Animatable(0.6f) }

    LaunchedEffect(Unit) { delay(1200); minTimePassed = true }
    LaunchedEffect(Unit) { scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy)) }
    LaunchedEffect(ready, minTimePassed) { if (ready && minTimePassed) currentOnFinished() }

    Box(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.scale(scale.value)) {
            Text("🍚", fontSize = 72.sp)
            Spacer(Modifier.height(12.dp))
            Text("MakanYuk", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
            Text("Jangan lupa makan ya!", style = MaterialTheme.typography.bodyLarge)
        }
    }
}
