package com.makanyuk.app.ui.screens.foods

import android.database.sqlite.SQLiteConstraintException
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.makanyuk.app.AppContainer
import com.makanyuk.app.data.local.entity.FoodItem
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class FoodListViewModel(private val container: AppContainer) : ViewModel() {

    val query = MutableStateFlow("")

    val items: StateFlow<List<FoodItem>> = query
        .flatMapLatest { container.foodItems.observe(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    fun setQuery(q: String) { query.value = q }

    fun add(name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        viewModelScope.launch {
            if (!container.foodItems.add(n)) _messages.emit("\"$n\" sudah ada di daftar")
        }
    }

    fun rename(item: FoodItem, name: String) {
        val n = name.trim()
        if (n.isEmpty() || n == item.name) return
        viewModelScope.launch {
            try {
                container.foodItems.update(item.copy(name = n))
            } catch (e: SQLiteConstraintException) {
                _messages.emit("\"$n\" sudah ada di daftar")
            }
        }
    }

    fun toggleFavorite(item: FoodItem) {
        viewModelScope.launch { container.foodItems.toggleFavorite(item) }
    }

    fun delete(item: FoodItem) {
        viewModelScope.launch { container.foodItems.delete(item) }
    }
}
