package com.makanyuk.app.ui.screens.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.makanyuk.app.AppContainer
import com.makanyuk.app.data.local.entity.FoodEntry
import com.makanyuk.app.domain.StatsCalculator
import com.makanyuk.app.ui.components.*
import com.makanyuk.app.ui.screens.history.EntriesViewModel
import com.makanyuk.app.ui.util.*
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun CalendarScreen(container: AppContainer, onEditEntry: (Long) -> Unit) {
    val vm: EntriesViewModel = viewModel(factory = SimpleFactory { EntriesViewModel(container) })
    val entries by vm.entries.collectAsStateWithLifecycle()
    var monthEpoch by rememberSaveable { mutableStateOf(YearMonth.now().atDay(1).toEpochDay()) }
    var selectedEpoch by rememberSaveable { mutableStateOf(LocalDate.now().toEpochDay()) }
    var toDelete by remember { mutableStateOf<FoodEntry?>(null) }

    val month = YearMonth.from(LocalDate.ofEpochDay(monthEpoch))
    val selected = LocalDate.ofEpochDay(selectedEpoch)
    val today = LocalDate.now()
    val counts = remember(entries) {
        entries.filter { it.eaten }.groupingBy { StatsCalculator.dateOf(it) }.eachCount()
    }
    val selectedEntries = remember(entries, selectedEpoch) {
        entries.filter { StatsCalculator.dateOf(it) == selected }.sortedBy { it.timeMillis }
    }

    toDelete?.let { e ->
        ConfirmDialog(
            title = "Hapus catatan?",
            text = "\"${e.name}\" akan dihapus dari riwayat.",
            confirmLabel = "Hapus",
            onConfirm = { vm.delete(e); toDelete = null },
            onDismiss = { toDelete = null }
        )
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Kalender makan", style = MaterialTheme.typography.headlineMedium) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { monthEpoch = month.minusMonths(1).atDay(1).toEpochDay() }) {
                    Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, contentDescription = "Bulan sebelumnya")
                }
                Text(
                    formatMonthYear(month),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
                IconButton(onClick = { monthEpoch = month.plusMonths(1).atDay(1).toEpochDay() }) {
                    Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = "Bulan berikutnya")
                }
            }
        }
        item {
            AppCard {
                Column(Modifier.padding(8.dp)) {
                    Row(Modifier.fillMaxWidth()) {
                        DayLabels.forEach {
                            Text(
                                it,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                    val offset = month.atDay(1).dayOfWeek.value - 1
                    val rows = (offset + month.lengthOfMonth() + 6) / 7
                    repeat(rows) { r ->
                        Row(Modifier.fillMaxWidth()) {
                            repeat(7) { c ->
                                val dayNumber = r * 7 + c - offset + 1
                                if (dayNumber in 1..month.lengthOfMonth()) {
                                    val d = month.atDay(dayNumber)
                                    DayCell(
                                        day = d,
                                        count = counts[d] ?: 0,
                                        isSelected = d == selected,
                                        isToday = d == today,
                                        modifier = Modifier.weight(1f),
                                        onClick = { selectedEpoch = d.toEpochDay() }
                                    )
                                } else {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                Text("Ada makanan tercatat", style = MaterialTheme.typography.labelMedium)
            }
        }
        item { SectionTitle(formatDateLong(selected)) }
        item {
            AppCard {
                if (selectedEntries.isEmpty()) {
                    Text("Belum ada catatan di hari ini.", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
                } else {
                    selectedEntries.forEach { e ->
                        FoodEntryRow(e, onClick = { onEditEntry(e.id) }, onDelete = { toDelete = e })
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    day: LocalDate,
    count: Int,
    isSelected: Boolean,
    isToday: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(12.dp)
    val bg = when {
        isSelected -> MaterialTheme.colorScheme.primary
        count > 0 -> MaterialTheme.colorScheme.primaryContainer
        else -> androidx.compose.ui.graphics.Color.Transparent
    }
    val fg = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Box(
        modifier = modifier
            .padding(2.dp)
            .aspectRatio(1f)
            .clip(shape)
            .background(bg)
            .then(if (isToday) Modifier.border(1.5.dp, MaterialTheme.colorScheme.primary, shape) else Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${day.dayOfMonth}", color = fg, style = MaterialTheme.typography.bodyMedium)
            Box(
                Modifier
                    .padding(top = 2.dp)
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            count == 0 -> androidx.compose.ui.graphics.Color.Transparent
                            isSelected -> MaterialTheme.colorScheme.onPrimary
                            else -> MaterialTheme.colorScheme.primary
                        }
                    )
            )
        }
    }
}
