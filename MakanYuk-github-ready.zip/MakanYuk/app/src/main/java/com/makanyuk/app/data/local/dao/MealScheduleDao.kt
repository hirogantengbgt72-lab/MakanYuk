package com.makanyuk.app.data.local.dao

import androidx.room.*
import com.makanyuk.app.data.local.entity.MealSchedule
import kotlinx.coroutines.flow.Flow

@Dao
interface MealScheduleDao {
    @Insert suspend fun insert(schedule: MealSchedule): Long
    @Insert suspend fun insertAll(schedules: List<MealSchedule>)
    @Update suspend fun update(schedule: MealSchedule)
    @Delete suspend fun delete(schedule: MealSchedule)

    @Query("SELECT * FROM meal_schedule WHERE id = :id")
    suspend fun getById(id: Long): MealSchedule?

    @Query("SELECT * FROM meal_schedule ORDER BY hour, minute")
    fun observeAll(): Flow<List<MealSchedule>>

    @Query("SELECT * FROM meal_schedule ORDER BY hour, minute")
    suspend fun getAll(): List<MealSchedule>

    @Query("DELETE FROM meal_schedule")
    suspend fun deleteAll()
}
