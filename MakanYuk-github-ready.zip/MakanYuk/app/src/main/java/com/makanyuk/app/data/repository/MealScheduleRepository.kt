package com.makanyuk.app.data.repository

import com.makanyuk.app.data.local.dao.MealScheduleDao
import com.makanyuk.app.data.local.entity.MealSchedule

class MealScheduleRepository(private val dao: MealScheduleDao) {
    fun observeAll() = dao.observeAll()
    suspend fun getAll() = dao.getAll()
    suspend fun getById(id: Long) = dao.getById(id)
    suspend fun save(schedule: MealSchedule): Long =
        if (schedule.id == 0L) dao.insert(schedule) else { dao.update(schedule); schedule.id }
    suspend fun delete(schedule: MealSchedule) = dao.delete(schedule)
}
