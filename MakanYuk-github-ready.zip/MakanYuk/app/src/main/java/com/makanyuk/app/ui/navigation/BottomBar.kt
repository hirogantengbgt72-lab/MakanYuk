package com.makanyuk.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector

private data class BottomItem(val route: String, val label: String, val icon: ImageVector)

private val items = listOf(
    BottomItem(Routes.HOME, "Beranda", Icons.Rounded.Home),
    BottomItem(Routes.SCHEDULE, "Jadwal", Icons.Rounded.Schedule),
    BottomItem(Routes.HISTORY, "Riwayat", Icons.Rounded.History),
    BottomItem(Routes.CALENDAR, "Kalender", Icons.Rounded.CalendarMonth),
    BottomItem(Routes.SETTINGS, "Pengaturan", Icons.Rounded.Settings)
)

@Composable
fun MakanYukBottomBar(currentRoute: String?, onNavigate: (String) -> Unit) {
    NavigationBar {
        items.forEach { item ->
            NavigationBarItem(
                selected = currentRoute == item.route,
                onClick = { onNavigate(item.route) },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) }
            )
        }
    }
}
