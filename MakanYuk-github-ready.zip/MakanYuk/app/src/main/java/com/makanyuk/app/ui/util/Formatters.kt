package com.makanyuk.app.ui.util

import com.makanyuk.app.domain.model.MealCategory
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

val IndonesianLocale: Locale = Locale.forLanguageTag("id-ID")

/** 1 = Senin ... 7 = Minggu */
val DayLabels = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")

val MealCategory.emoji: String
    get() = when (this) {
        MealCategory.SARAPAN -> "🍳"
        MealCategory.MAKAN_SIANG -> "🍛"
        MealCategory.MAKAN_MALAM -> "🍲"
        MealCategory.CAMILAN -> "🍌"
    }

fun categoryEmoji(name: String): String = MealCategory.fromName(name).emoji

fun formatTime(hour: Int, minute: Int): String = String.format(IndonesianLocale, "%02d.%02d", hour, minute)
fun formatTime(t: LocalTime): String = formatTime(t.hour, t.minute)

fun formatDateLong(d: LocalDate): String =
    d.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", IndonesianLocale))

fun formatDateShort(d: LocalDate): String =
    d.format(DateTimeFormatter.ofPattern("d MMM yyyy", IndonesianLocale))

fun millisToDateTime(millis: Long): LocalDateTime =
    LocalDateTime.ofInstant(Instant.ofEpochMilli(millis), ZoneId.systemDefault())

fun dateTimeToMillis(dt: LocalDateTime): Long =
    dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

/** Awal hari ini sampai awal besok, dalam milidetik. */
fun dayBounds(date: LocalDate): Pair<Long, Long> {
    val zone = ZoneId.systemDefault()
    return date.atStartOfDay(zone).toInstant().toEpochMilli() to
        date.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
}

/** Pasangan (salam, kalimat penyemangat). */
fun greetingFor(hour: Int): Pair<String, String> = when (hour) {
    in 4..10 -> "Selamat pagi" to "Jangan lupa makan ya!"
    in 11..14 -> "Selamat siang" to "Sudah makan siang belum?"
    in 15..17 -> "Selamat sore" to "Jangan lupa camilan sore ya!"
    else -> "Selamat malam" to "Jangan sampai lewat makan malam ya!"
}

fun formatCountdown(from: LocalDateTime, to: LocalDateTime): String {
    val minutes = Duration.between(from, to).toMinutes()
    return when {
        minutes <= 0 -> "Kurang dari 1 menit lagi"
        minutes < 60 -> "$minutes menit lagi"
        else -> {
            val h = minutes / 60
            val m = minutes % 60
            if (m == 0L) "$h jam lagi" else "$h jam $m menit lagi"
        }
    }
}

fun formatWhen(today: LocalDate, target: LocalDateTime): String {
    val time = formatTime(target.toLocalTime())
    val date = target.toLocalDate()
    return when (date) {
        today -> "Hari ini • $time"
        today.plusDays(1) -> "Besok • $time"
        else -> date.format(DateTimeFormatter.ofPattern("EEEE", IndonesianLocale)) + " • $time"
    }
}

fun formatMonthYear(ym: java.time.YearMonth): String =
    ym.format(DateTimeFormatter.ofPattern("MMMM yyyy", IndonesianLocale))

/** "9 – 15 Nov 2026" atau "28 Okt – 3 Nov 2026" */
fun formatWeekRange(start: LocalDate): String {
    val end = start.plusDays(6)
    return if (start.month == end.month) {
        "${start.dayOfMonth} – " + end.format(DateTimeFormatter.ofPattern("d MMM yyyy", IndonesianLocale))
    } else {
        start.format(DateTimeFormatter.ofPattern("d MMM", IndonesianLocale)) + " – " +
            end.format(DateTimeFormatter.ofPattern("d MMM yyyy", IndonesianLocale))
    }
}

/** bit 0 = Senin ... bit 6 = Minggu */
fun daysSummary(mask: Int): String = when (mask) {
    127 -> "Setiap hari"
    0 -> "Tidak ada hari dipilih"
    else -> (0..6).filter { (mask and (1 shl it)) != 0 }.joinToString(", ") { DayLabels[it] }
}
