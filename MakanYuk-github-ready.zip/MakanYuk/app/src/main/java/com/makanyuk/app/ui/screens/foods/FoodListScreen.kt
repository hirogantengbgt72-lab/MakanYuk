package com.makanyuk.app.ui.screens.foods

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.makanyuk.app.AppContainer
import com.makanyuk.app.data.local.entity.FoodItem
import com.makanyuk.app.ui.components.ConfirmDialog
import com.makanyuk.app.ui.components.NoInsets
import com.makanyuk.app.ui.util.SimpleFactory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoodListScreen(container: AppContainer, onBack: () -> Unit) {
    val vm: FoodListViewModel = viewModel(factory = SimpleFactory { FoodListViewModel(container) })
    val items by vm.items.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<FoodItem?>(null) }
    var deleting by remember { mutableStateOf<FoodItem?>(null) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    if (adding) {
        FoodNameDialog(
            title = "Tambah makanan",
            initial = "",
            onDismiss = { adding = false },
            onSave = { vm.add(it); adding = false }
        )
    }
    editing?.let { item ->
        FoodNameDialog(
            title = "Ubah nama makanan",
            initial = item.name,
            onDismiss = { editing = null },
            onSave = { vm.rename(item, it); editing = null }
        )
    }
    deleting?.let { item ->
        ConfirmDialog(
            title = "Hapus dari daftar?",
            text = "\"${item.name}\" akan dihapus dari daftar makanan. Riwayat makan tidak berubah.",
            confirmLabel = "Hapus",
            onConfirm = { vm.delete(item); deleting = null },
            onDismiss = { deleting = null }
        )
    }

    Scaffold(
        contentWindowInsets = NoInsets,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                windowInsets = NoInsets,
                title = { Text("Daftar makanan") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { adding = true }) {
                Icon(Icons.Rounded.Add, contentDescription = "Tambah makanan")
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = vm::setQuery,
                placeholder = { Text("Cari makanan") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                shape = MaterialTheme.shapes.extraLarge,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            )
            if (items.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(
                        if (query.isBlank()) "Daftar masih kosong. Tekan + untuk menambah."
                        else "Tidak ada makanan yang cocok.",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 8.dp, top = 4.dp, bottom = 88.dp)) {
                    items(items, key = { it.id }) { item ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                item.name,
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.weight(1f).padding(vertical = 12.dp)
                            )
                            IconButton(onClick = { vm.toggleFavorite(item) }) {
                                Icon(
                                    if (item.isFavorite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                                    contentDescription = if (item.isFavorite) "Hapus dari favorit" else "Jadikan favorit",
                                    tint = if (item.isFavorite) MaterialTheme.colorScheme.tertiary
                                    else MaterialTheme.colorScheme.outline
                                )
                            }
                            IconButton(onClick = { editing = item }) {
                                Icon(Icons.Rounded.Edit, contentDescription = "Ubah nama")
                            }
                            IconButton(onClick = { deleting = item }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Hapus")
                            }
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
private fun FoodNameDialog(title: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nama makanan") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onSave(name) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
