package com.makanyuk.app.ui.screens.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.makanyuk.app.AppContainer
import com.makanyuk.app.data.local.entity.FoodEntry
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Dipakai layar Riwayat dan Kalender. */
class EntriesViewModel(private val container: AppContainer) : ViewModel() {

    val entries: StateFlow<List<FoodEntry>> = container.foodEntries.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun delete(entry: FoodEntry) {
        viewModelScope.launch { container.foodEntries.delete(entry) }
    }
}
