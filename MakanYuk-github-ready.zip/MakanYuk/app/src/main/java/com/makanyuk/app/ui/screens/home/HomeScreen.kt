package com.makanyuk.app.ui.screens.home

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.makanyuk.app.AppContainer
import com.makanyuk.app.data.local.entity.FoodEntry
import com.makanyuk.app.data.local.entity.MealSchedule
import com.makanyuk.app.domain.model.MealCategory
import com.makanyuk.app.ui.components.AppCard
import com.makanyuk.app.ui.components.ConfirmDialog
import com.makanyuk.app.ui.components.QuickEatDialog
import com.makanyuk.app.ui.components.SectionTitle
import com.makanyuk.app.ui.util.*

@Composable
fun HomeScreen(container: AppContainer, onAddFood: () -> Unit, onEditEntry: (Long) -> Unit) {
    val vm: HomeViewModel = viewModel(factory = SimpleFactory { HomeViewModel(container) })
    val state by vm.state.collectAsStateWithLifecycle()
    var quickFor by remember { mutableStateOf<MealSchedule?>(null) }
    var entryToDelete by remember { mutableStateOf<FoodEntry?>(null) }
    val ui = state ?: return

    quickFor?.let { schedule ->
        QuickEatDialog(
            title = "Sudah makan: ${schedule.name}",
            suggestions = ui.suggestions,
            onDismiss = { quickFor = null },
            onSave = { vm.markEaten(schedule, it); quickFor = null }
        )
    }
    entryToDelete?.let { entry ->
        ConfirmDialog(
            title = "Hapus catatan?",
            text = "\"${entry.name}\" akan dihapus dari riwayat.",
            confirmLabel = "Hapus",
            onConfirm = { vm.deleteEntry(entry); entryToDelete = null },
            onDismiss = { entryToDelete = null }
        )
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Header(ui) }
            item { NextCard(ui, onSudahMakan = { quickFor = it }, onAddFood = onAddFood) }
            item { ProgressCard(ui) }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle("Jadwal hari ini")
                    AppCard {
                        if (ui.statuses.isEmpty()) {
                            Text(
                                "Tidak ada jadwal aktif hari ini. Atur di tab Jadwal.",
                                modifier = Modifier.padding(16.dp),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        } else {
                            ui.statuses.forEach { st ->
                                ScheduleRow(st) { quickFor = st.schedule }
                            }
                        }
                    }
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionTitle("Makananmu hari ini")
                    AppCard {
                        if (ui.entries.isEmpty()) {
                            Text(
                                "Belum ada makanan yang dicatat. Tekan \"Sudah Makan\" atau tombol tambah.",
                                modifier = Modifier.padding(16.dp),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        } else {
                            ui.entries.forEach { e ->
                                EntryRow(e, onClick = { onEditEntry(e.id) }, onDelete = { entryToDelete = e })
                            }
                        }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = onAddFood,
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
            text = { Text("Tambah makanan") }
        )
    }
}

@Composable
private fun Header(ui: HomeUiState) {
    val (salam, tagline) = greetingFor(ui.now.hour)
    val title = if (ui.userName.isBlank()) "$salam!" else "$salam, ${ui.userName}!"
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onBackground)
        Text(tagline, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            formatDateLong(ui.now.toLocalDate()),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
private fun NextCard(ui: HomeUiState, onSudahMakan: (MealSchedule) -> Unit, onAddFood: () -> Unit) {
    AppCard(containerColor = MaterialTheme.colorScheme.primaryContainer) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Pengingat berikutnya", style = MaterialTheme.typography.labelLarge)
            val next = ui.next
            if (next != null) {
                val (schedule, time) = next
                Text(
                    "${MealCategory.fromName(schedule.category).emoji} ${schedule.name}",
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    formatCountdown(ui.now, time),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(formatWhen(ui.now.toLocalDate(), time), style = MaterialTheme.typography.bodyMedium)
            } else {
                Text(
                    "Belum ada jadwal aktif. Atur di tab Jadwal.",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            Spacer(Modifier.height(8.dp))
            val focus = ui.focus
            if (focus != null) {
                Button(onClick = { onSudahMakan(focus) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Check, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Sudah Makan • ${focus.name}")
                }
            } else {
                FilledTonalButton(onClick = onAddFood, modifier = Modifier.fillMaxWidth()) {
                    Text("Tambah makanan")
                }
            }
        }
    }
}

@Composable
private fun ProgressCard(ui: HomeUiState) {
    val target = if (ui.total == 0) 0f else ui.doneCount.toFloat() / ui.total
    val progress by animateFloatAsState(target, label = "progress")
    val message = when {
        ui.total == 0 -> "Santai saja hari ini."
        ui.doneCount == ui.total -> "Hebat! Semua jadwal hari ini sudah selesai 🎉"
        ui.doneCount > 0 -> "Sedikit lagi, semangat!"
        else -> "Yuk mulai makan hari ini!"
    }
    AppCard {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Progress makan hari ini", style = MaterialTheme.typography.titleMedium)
                Text("${ui.doneCount}/${ui.total}", style = MaterialTheme.typography.titleMedium)
            }
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)),
                trackColor = MaterialTheme.colorScheme.background
            )
            Text(message, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun ScheduleRow(status: ScheduleStatus, onMarkEaten: () -> Unit) {
    val s = status.schedule
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !status.done, onClick = onMarkEaten)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(categoryEmoji(s.category), fontSize = 24.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.name, style = MaterialTheme.typography.titleMedium)
            Text(formatTime(s.hour, s.minute), style = MaterialTheme.typography.bodyMedium)
        }
        if (status.done) {
            Icon(Icons.Rounded.CheckCircle, contentDescription = "Sudah makan", tint = MaterialTheme.colorScheme.primary)
        } else {
            Icon(Icons.Rounded.RadioButtonUnchecked, contentDescription = "Tandai sudah makan", tint = MaterialTheme.colorScheme.outline)
        }
    }
}

@Composable
private fun EntryRow(entry: FoodEntry, onClick: () -> Unit, onDelete: () -> Unit) {
    val time = millisToDateTime(entry.timeMillis).toLocalTime()
    val category = MealCategory.fromName(entry.category)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(category.emoji, fontSize = 24.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(entry.name, style = MaterialTheme.typography.titleMedium)
            val status = if (entry.eaten) "" else " • Rencana"
            Text("${formatTime(time)} • ${category.label}$status", style = MaterialTheme.typography.bodyMedium)
        }
        IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, contentDescription = "Hapus") }
    }
}
