package com.makanyuk.app.ui.screens.addfood

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.makanyuk.app.AppContainer
import com.makanyuk.app.data.local.entity.FoodEntry
import com.makanyuk.app.domain.ScheduleResolver
import com.makanyuk.app.domain.model.MealCategory
import com.makanyuk.app.ui.util.dateTimeToMillis
import com.makanyuk.app.ui.util.dayBounds
import com.makanyuk.app.ui.util.millisToDateTime
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime

@OptIn(ExperimentalCoroutinesApi::class)
class AddFoodViewModel(private val container: AppContainer, private val entryId: Long) : ViewModel() {

    val isEdit = entryId >= 0

    var name by mutableStateOf("")
    var category by mutableStateOf(MealCategory.defaultFor(LocalDateTime.now().hour))
    var dateTime by mutableStateOf(LocalDateTime.now().withSecond(0).withNano(0))
    var note by mutableStateOf("")
    var eaten by mutableStateOf(true)
    var nameError by mutableStateOf(false)
    var loaded by mutableStateOf(!isEdit)

    private var original: FoodEntry? = null

    init {
        if (isEdit) {
            viewModelScope.launch {
                container.foodEntries.getById(entryId)?.let { e ->
                    original = e
                    name = e.name
                    category = MealCategory.fromName(e.category)
                    dateTime = millisToDateTime(e.timeMillis)
                    note = e.note
                    eaten = e.eaten
                }
                loaded = true
            }
        }
    }

    /** Saran dari daftar makanan; favorit tampil dulu. */
    val suggestions: StateFlow<List<String>> = snapshotFlow { name }
        .flatMapLatest { q ->
            container.foodItems.observe(q).map { list ->
                list.map { it.name }.filterNot { it.equals(q.trim(), ignoreCase = true) }.take(6)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun save(onDone: () -> Unit) {
        val cleanName = name.trim()
        if (cleanName.isEmpty()) {
            nameError = true
            return
        }
        viewModelScope.launch {
            val millis = dateTimeToMillis(dateTime)
            val base = original
            if (base == null) {
                val link = if (eaten && dateTime.toLocalDate() == LocalDate.now()) findScheduleToLink() else null
                container.foodEntries.save(
                    FoodEntry(
                        name = cleanName, timeMillis = millis, category = category.name,
                        note = note.trim(), eaten = eaten, scheduleId = link
                    )
                )
            } else {
                container.foodEntries.save(
                    base.copy(
                        name = cleanName, timeMillis = millis, category = category.name,
                        note = note.trim(), eaten = eaten
                    )
                )
            }
            container.foodItems.add(cleanName)
            onDone()
        }
    }

    fun delete(onDone: () -> Unit) {
        viewModelScope.launch {
            original?.let { container.foodEntries.delete(it) }
            onDone()
        }
    }

    /** Mengaitkan catatan baru ke jadwal hari ini yang cocok agar progress harian ikut naik. */
    private suspend fun findScheduleToLink(): Long? {
        val today = LocalDate.now()
        val prefs = container.prefs.current()
        val active = ScheduleResolver.forDay(container.schedules.getAll(), today.dayOfWeek, prefs.schoolDays)
        val (start, end) = dayBounds(today)
        val doneIds = container.foodEntries.observeBetween(start, end).first()
            .filter { it.eaten }.mapNotNull { it.scheduleId }.toSet()
        return ScheduleResolver.autoLink(active, doneIds, category.name, dateTime.toLocalTime())
    }
}
