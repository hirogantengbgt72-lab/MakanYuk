package com.makanyuk.app.domain

import com.makanyuk.app.data.local.entity.FoodEntry
import com.makanyuk.app.domain.model.MealCategory
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

data class DayCount(val date: LocalDate, val count: Int)

data class FoodSummary(val name: String, val count: Int, val lastEaten: LocalDate)

data class HabitStats(
    val days: Int,
    val totalEaten: Int,
    val activeDays: Int,
    val averagePerActiveDay: Double,
    val streak: Int,
    val topFoods: List<Pair<String, Int>>,
    val categoryCounts: Map<MealCategory, Int>
)

/** Hanya catatan dengan eaten = true yang dihitung sebagai "sudah makan". */
object StatsCalculator {

    fun dateOf(e: FoodEntry): LocalDate =
        Instant.ofEpochMilli(e.timeMillis).atZone(ZoneId.systemDefault()).toLocalDate()

    fun weekStart(date: LocalDate): LocalDate = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

    fun weekCounts(entries: List<FoodEntry>, start: LocalDate): List<DayCount> {
        val byDate = entries.filter { it.eaten }.groupingBy { dateOf(it) }.eachCount()
        return (0..6).map { i ->
            val d = start.plusDays(i.toLong())
            DayCount(d, byDate[d] ?: 0)
        }
    }

    fun compute(entries: List<FoodEntry>, today: LocalDate, days: Int = 30): HabitStats {
        val from = today.minusDays((days - 1).toLong())
        val eaten = entries.filter { it.eaten }
        val inRange = eaten.filter { val d = dateOf(it); !d.isBefore(from) && !d.isAfter(today) }

        val allDates = eaten.map { dateOf(it) }.toSet()
        var streak = 0
        var cursor = if (today in allDates) today else today.minusDays(1)
        while (cursor in allDates) {
            streak++
            cursor = cursor.minusDays(1)
        }

        val activeDays = inRange.map { dateOf(it) }.toSet().size
        val top = inRange
            .groupBy { it.name.trim().lowercase() }
            .map { (_, list) -> list.first().name.trim() to list.size }
            .sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first })
            .take(5)

        return HabitStats(
            days = days,
            totalEaten = inRange.size,
            activeDays = activeDays,
            averagePerActiveDay = if (activeDays == 0) 0.0 else inRange.size.toDouble() / activeDays,
            streak = streak,
            topFoods = top,
            categoryCounts = MealCategory.entries.associateWith { c -> inRange.count { it.category == c.name } }
        )
    }

    /** Semua makanan yang pernah dicatat (sudah dimakan), terbaru di atas. */
    fun distinctFoods(entries: List<FoodEntry>): List<FoodSummary> =
        entries.filter { it.eaten }
            .groupBy { it.name.trim().lowercase() }
            .map { (_, list) ->
                val latest = list.maxByOrNull { it.timeMillis }!!
                FoodSummary(latest.name.trim(), list.size, dateOf(latest))
            }
            .sortedByDescending { it.lastEaten }
}
