package com.makanyuk.app.data.local.dao

import androidx.room.*
import com.makanyuk.app.data.local.entity.FoodItem
import kotlinx.coroutines.flow.Flow

@Dao
interface FoodItemDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(item: FoodItem): Long
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertAll(items: List<FoodItem>)
    @Update suspend fun update(item: FoodItem)
    @Delete suspend fun delete(item: FoodItem)

    @Query("SELECT * FROM food_item ORDER BY isFavorite DESC, name COLLATE NOCASE ASC")
    fun observeAll(): Flow<List<FoodItem>>

    @Query("SELECT * FROM food_item WHERE name LIKE '%' || :query || '%' ORDER BY isFavorite DESC, name COLLATE NOCASE ASC")
    fun search(query: String): Flow<List<FoodItem>>

    @Query("SELECT * FROM food_item")
    suspend fun getAll(): List<FoodItem>

    @Query("DELETE FROM food_item")
    suspend fun deleteAll()
}
