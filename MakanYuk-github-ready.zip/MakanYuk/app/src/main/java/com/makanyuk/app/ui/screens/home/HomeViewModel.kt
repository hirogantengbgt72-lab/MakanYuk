package com.makanyuk.app.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.makanyuk.app.AppContainer
import com.makanyuk.app.data.local.entity.FoodEntry
import com.makanyuk.app.data.local.entity.MealSchedule
import com.makanyuk.app.domain.ScheduleResolver
import com.makanyuk.app.ui.util.dayBounds
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import kotlin.math.abs

data class ScheduleStatus(val schedule: MealSchedule, val done: Boolean)

data class HomeUiState(
    val userName: String,
    val now: LocalDateTime,
    val statuses: List<ScheduleStatus>,
    val entries: List<FoodEntry>,
    val next: Pair<MealSchedule, LocalDateTime>?,
    val focus: MealSchedule?,
    val suggestions: List<String>
) {
    val doneCount: Int get() = statuses.count { it.done }
    val total: Int get() = statuses.size
}

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModel(private val container: AppContainer) : ViewModel() {

    private val clock = MutableStateFlow(LocalDateTime.now())

    init {
        viewModelScope.launch {
            while (true) {
                delay(10_000)
                clock.value = LocalDateTime.now()
            }
        }
    }

    private val todayEntries = clock
        .map { it.toLocalDate() }
        .distinctUntilChanged()
        .flatMapLatest { date ->
            val (start, end) = dayBounds(date)
            container.foodEntries.observeBetween(start, end)
        }

    val state: StateFlow<HomeUiState?> = combine(
        container.prefs.flow,
        container.schedules.observeAll(),
        todayEntries,
        clock,
        container.foodItems.observe("")
    ) { prefs, schedules, entries, now, foods ->
        val today = now.toLocalDate()
        val active = ScheduleResolver.forDay(schedules, today.dayOfWeek, prefs.schoolDays)
        val doneIds = entries.filter { it.eaten }.mapNotNull { it.scheduleId }.toSet()
        val statuses = active.map { ScheduleStatus(it, it.id in doneIds) }
        val nowMinutes = now.hour * 60 + now.minute
        val focus = statuses.filter { !it.done }
            .minByOrNull { abs(ScheduleResolver.minutesOfDay(it.schedule) - nowMinutes) }
            ?.schedule
        HomeUiState(
            userName = prefs.userName,
            now = now,
            statuses = statuses,
            entries = entries,
            next = ScheduleResolver.nextOccurrence(schedules, prefs.schoolDays, now),
            focus = focus,
            suggestions = foods.take(8).map { it.name }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun markEaten(schedule: MealSchedule, foodName: String) {
        val name = foodName.trim()
        if (name.isEmpty()) return
        viewModelScope.launch {
            container.foodEntries.save(
                FoodEntry(
                    name = name,
                    timeMillis = System.currentTimeMillis(),
                    category = schedule.category,
                    scheduleId = schedule.id
                )
            )
            container.foodItems.add(name)
        }
    }

    fun deleteEntry(entry: FoodEntry) {
        viewModelScope.launch { container.foodEntries.delete(entry) }
    }
}
