package com.makanyuk.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.makanyuk.app.data.prefs.UserPreferences
import com.makanyuk.app.domain.model.ThemeMode
import com.makanyuk.app.ui.navigation.MakanYukRoot
import com.makanyuk.app.ui.theme.MakanYukTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as MakanYukApp).container
        setContent {
            val prefs: UserPreferences? by container.prefs.flow.collectAsStateWithLifecycle(initialValue = null)
            MakanYukTheme(themeMode = prefs?.themeMode ?: ThemeMode.SYSTEM) {
                MakanYukRoot(container, prefs)
            }
        }
    }
}
