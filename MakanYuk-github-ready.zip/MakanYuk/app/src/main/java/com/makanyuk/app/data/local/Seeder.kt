package com.makanyuk.app.data.local

import com.makanyuk.app.data.local.entity.FoodItem
import com.makanyuk.app.data.local.entity.MealSchedule
import com.makanyuk.app.domain.model.MealCategory

/** Data awal sesuai jadwal & daftar makanan bawaan. Semuanya bisa diedit/dihapus pengguna. */
object Seeder {
    private val defaultSchedules = listOf(
        MealSchedule(name = "Sarapan", hour = 6, minute = 0, category = MealCategory.SARAPAN.name,
            message = "Selamat pagi! Waktunya sarapan di rumah.", skipOnSchoolDays = true),
        MealSchedule(name = "Camilan", hour = 9, minute = 0, category = MealCategory.CAMILAN.name,
            message = "Jangan lupa camilan ya."),
        MealSchedule(name = "Makan siang", hour = 12, minute = 30, category = MealCategory.MAKAN_SIANG.name,
            message = "Waktunya makan siang!"),
        MealSchedule(name = "Camilan sore", hour = 15, minute = 30, category = MealCategory.CAMILAN.name,
            message = "Jangan lupa camilan sore."),
        MealSchedule(name = "Makan malam", hour = 19, minute = 0, category = MealCategory.MAKAN_MALAM.name,
            message = "Sudah waktunya makan malam."),
        MealSchedule(name = "Camilan tambahan", hour = 20, minute = 30, category = MealCategory.CAMILAN.name,
            message = "Kalau lapar, boleh ambil camilan. Jangan lupa makan hari ini!")
    )

    private val defaultFoods = listOf(
        "Nasi goreng", "Nasi putih", "Telur ceplok", "Tempe goreng", "Ayam goreng", "Mi goreng",
        "Nasi kuning", "Pisang", "Rambutan", "Roti", "Ubi rebus", "Jagung rebus"
    )

    suspend fun seed(db: AppDatabase) {
        db.mealScheduleDao().insertAll(defaultSchedules)
        db.foodItemDao().insertAll(defaultFoods.map { FoodItem(name = it) })
    }
}
