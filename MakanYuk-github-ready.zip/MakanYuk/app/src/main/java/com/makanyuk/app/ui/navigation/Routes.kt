package com.makanyuk.app.ui.navigation

object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val SCHEDULE = "schedule"
    const val HISTORY = "history"
    const val CALENDAR = "calendar"
    const val SETTINGS = "settings"
    const val FOODS = "foods"
    const val ADD_FOOD = "add_food?entryId={entryId}"
    const val ARG_ENTRY_ID = "entryId"

    fun addFood(entryId: Long = -1L) = "add_food?entryId=$entryId"

    val bottomBarRoutes = setOf(HOME, SCHEDULE, HISTORY, CALENDAR, SETTINGS)
}
