package com.makanyuk.app.ui.screens.schedule

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.makanyuk.app.data.local.entity.MealSchedule
import com.makanyuk.app.domain.model.MealCategory
import com.makanyuk.app.ui.components.AppTimePickerDialog
import com.makanyuk.app.ui.components.CategoryChips
import com.makanyuk.app.ui.util.DayLabels
import com.makanyuk.app.ui.util.formatTime
import java.time.LocalTime

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScheduleEditDialog(
    initial: MealSchedule,
    onDismiss: () -> Unit,
    onSave: (MealSchedule) -> Unit,
    onDelete: (() -> Unit)?
) {
    var name by remember { mutableStateOf(initial.name) }
    var hour by remember { mutableStateOf(initial.hour) }
    var minute by remember { mutableStateOf(initial.minute) }
    var category by remember { mutableStateOf(MealCategory.fromName(initial.category)) }
    var message by remember { mutableStateOf(initial.message) }
    var daysMask by remember { mutableStateOf(initial.daysMask) }
    var skipOnSchool by remember { mutableStateOf(initial.skipOnSchoolDays) }
    var enabled by remember { mutableStateOf(initial.enabled) }
    var nameError by remember { mutableStateOf(false) }
    var showTime by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    if (showTime) {
        AppTimePickerDialog(
            initial = LocalTime.of(hour, minute),
            onConfirm = { hour = it.hour; minute = it.minute; showTime = false },
            onDismiss = { showTime = false }
        )
    }
    if (confirmDelete && onDelete != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Hapus jadwal?") },
            text = { Text("Jadwal \"${initial.name}\" dan pengingatnya akan dihapus.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Hapus") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Batal") } }
        )
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            tonalElevation = 6.dp,
            modifier = Modifier.padding(16.dp).fillMaxWidth().heightIn(max = 680.dp)
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()).padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    if (initial.id == 0L) "Tambah jadwal" else "Ubah jadwal",
                    style = MaterialTheme.typography.titleLarge
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; nameError = false },
                    label = { Text("Nama jadwal") },
                    isError = nameError,
                    supportingText = { if (nameError) Text("Nama wajib diisi") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(onClick = { showTime = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Schedule, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Jam: ${formatTime(hour, minute)}")
                }
                Text("Kategori", style = MaterialTheme.typography.titleMedium)
                CategoryChips(selected = category, onSelected = { category = it })

                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("Isi notifikasi (opsional)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Hari aktif", style = MaterialTheme.typography.titleMedium)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    DayLabels.forEachIndexed { i, label ->
                        val bit = 1 shl i
                        FilterChip(
                            selected = (daysMask and bit) != 0,
                            onClick = { daysMask = daysMask xor bit },
                            label = { Text(label) }
                        )
                    }
                }
                if (daysMask == 0) {
                    Text("Pilih minimal satu hari.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Lewati di hari sekolah", style = MaterialTheme.typography.titleMedium)
                        Text("Cocok untuk sarapan di rumah.", style = MaterialTheme.typography.bodyMedium)
                    }
                    Switch(checked = skipOnSchool, onCheckedChange = { skipOnSchool = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Aktif", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    Switch(checked = enabled, onCheckedChange = { enabled = it })
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    if (onDelete != null) {
                        TextButton(onClick = { confirmDelete = true }) { Text("Hapus") }
                        Spacer(Modifier.weight(1f))
                    }
                    TextButton(onClick = onDismiss) { Text("Batal") }
                    TextButton(onClick = {
                        val clean = name.trim()
                        if (clean.isEmpty()) {
                            nameError = true
                        } else if (daysMask != 0) {
                            onSave(
                                initial.copy(
                                    name = clean, hour = hour, minute = minute, category = category.name,
                                    message = message.trim().ifEmpty { "Waktunya $clean!" },
                                    enabled = enabled, daysMask = daysMask, skipOnSchoolDays = skipOnSchool
                                )
                            )
                        }
                    }) { Text("Simpan") }
                }
            }
        }
    }
}
